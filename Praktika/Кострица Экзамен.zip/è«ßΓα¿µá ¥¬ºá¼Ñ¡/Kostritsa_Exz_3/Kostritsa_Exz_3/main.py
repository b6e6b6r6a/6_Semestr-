from datetime import datetime, timedelta
from random import randint


def GetMarks(now, students):
   marks = {}
   for student in students:
       marks[student] = []
       current_date = now.date()
       for i in range(10):
           mark = randint(1, 10)
           next_date = current_date + timedelta(days=i)
           marks[student].append((next_date, mark))
   return marks