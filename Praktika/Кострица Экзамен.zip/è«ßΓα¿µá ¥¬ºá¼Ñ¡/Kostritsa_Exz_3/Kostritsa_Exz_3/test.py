import unittest
from datetime import datetime, timedelta
from main import GetMarks


class TestGetMarks(unittest.TestCase):

    def test_get_marks(self):
        now = datetime.now()
        students = [
            "Петров",
            "Иванов",
            "Сидоров"
        ]
        marks = GetMarks(now, students)

        self.assertEqual(len(marks), len(students))

        for student in students:
            self.assertEqual(len(marks[student]), 10)
            print(f"Student: {student}")
            for date, mark in marks[student]:
                print(f"Date: {date}, Mark: {mark}")

            current_date = now.date()
            for i in range(10):
                expected_date = current_date + timedelta(days=i)
                self.assertTrue(any(date == expected_date for date, mark in marks[student]))


if __name__ == '__main__':
    unittest.main()
