﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using Kostritsa_Exz_3;
using System.Collections.Generic;


namespace UnitTestKostritsa_Exz_3
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void GetMarks_ShouldGenerateMarksForStudents()
        {
            // 1. Организация (Arrange)
            DateTime now = DateTime.Now;
            List<Student> students = new List<Student>
            {
                new Student { Group = "ИВТ-123", YearOfAdmission = 2020, FullName = "Иванов Иван Иванович" },
                new Student { Group = "ИВТ-123", YearOfAdmission = 2020, FullName = "Петров Петр Петрович" }
            };


            List<Mark> generatedMarks = MarkGenerator.GetMarks(now, students);

            Assert.AreEqual(20, generatedMarks.Count);


        }
    }
}
