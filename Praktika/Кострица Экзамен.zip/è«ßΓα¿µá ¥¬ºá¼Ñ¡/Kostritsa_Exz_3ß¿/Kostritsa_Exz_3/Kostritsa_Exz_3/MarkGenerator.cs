﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kostritsa_Exz_3
{
    public class MarkGenerator
    {
        public static List<Mark> GetMarks(DateTime now, List<Student> students)
        {
            var marks = new List<Mark>();
            for (int i = 0; i < 10; i++)
            {
                DateTime date = now.AddDays(i);
                foreach (var student in students)
                {
                    // Генерируем случайную оценку и посещаемость
                    int attendance = new Random().Next(0, 2);
                    int? grade = null;
                    if (new Random().Next(0, 3) == 0) // 1/3 шанс получить оценку
                    {
                        grade = new Random().Next(2, 6);
                    }

                    marks.Add(new Mark
                    {
                        Student = student,
                        Date = date,
                        Attendance = attendance,
                        Grade = grade
                    });
                }
            }

            // Вывод сгенерированных оценок:
            foreach (var mark in marks)
            {
                Console.WriteLine($"Студент: {mark.Student.FullName}, Дата: {mark.Date.ToShortDateString()}, Посещаемость: {mark.Attendance}, Оценка: {mark.Grade}");
            }

            return marks;
        }
    }



    public class Student
    {
        public string Group { get; set; }
        public int YearOfAdmission { get; set; }
        public string FullName { get; set; }
    }

    public class Mark
    {
        public Student Student { get; set; }
        public DateTime Date { get; set; }
        public int Attendance { get; set; } // 0 - отсутствовал, 1 - присутствовал
        public int? Grade { get; set; } // null - не оценивалось
    }

}